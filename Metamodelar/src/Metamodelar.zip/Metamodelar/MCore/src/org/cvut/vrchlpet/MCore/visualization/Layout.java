

package org.cvut.vrchlpet.MCore.visualization;

/**
 *
 * @author Vrchlavsky Petr
 * @version 1.0
 */
public enum Layout {
    top,
    buttom,
    center,
    right,
    left,
}
