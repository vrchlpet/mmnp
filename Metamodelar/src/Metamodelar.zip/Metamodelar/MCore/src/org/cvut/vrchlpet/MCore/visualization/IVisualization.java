

package org.cvut.vrchlpet.MCore.visualization;



/**
 *
 * @author Vrchli
 */
public interface IVisualization<T> {
    public String getName();
}
