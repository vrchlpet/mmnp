/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.cvut.vrchlpet.MProject.nodes;

/**
 *
 * @author Vrchlavsky Petr
 * @version 1.0
 */
public class ProjectNode {

}
